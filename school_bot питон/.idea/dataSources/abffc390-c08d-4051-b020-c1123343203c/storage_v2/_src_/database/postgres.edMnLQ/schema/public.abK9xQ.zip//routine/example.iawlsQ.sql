create function example() returns numeric
    language plpgsql
as
$$
declare lol numeric;
BEGIN
    select count(*) from bookings.ticket_flights into lol  where amount > 20000;
    RETURN  lol;
END;
$$;

alter function example() owner to postgres;

