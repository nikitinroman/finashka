create function example(integer) returns integer
    language plpgsql
as
$$
declare lol integer;
BEGIN
    select count(*) from bookings.ticket_flights where bookings.ticket_flights.amount > $1 into lol;
    RETURN  lol;
END;
$$;

alter function example(integer) owner to postgres;

