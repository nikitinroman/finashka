create function return_out_int(OUT result1 integer, OUT result2 integer) returns record
    language plpgsql
as
$$
BEGIN
 result1 := 1;
 RETURN;
END
$$;

alter function return_out_int(out integer, out integer) owner to postgres;

