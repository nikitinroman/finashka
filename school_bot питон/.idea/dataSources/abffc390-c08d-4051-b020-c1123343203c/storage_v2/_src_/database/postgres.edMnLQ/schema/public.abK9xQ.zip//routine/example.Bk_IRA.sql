create function example(num numeric) returns numeric
    language plpgsql
as
$$
DECLARE
    x ALIAS FOR $1;
BEGIN
    select count(*) as lol from ticket_flights where amount > x;
    RETURN  lol;
END;
$$;

alter function example(numeric) owner to postgres;

