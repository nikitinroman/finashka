create function example(real) returns numeric
    language plpgsql
as
$$
DECLARE
    x ALIAS FOR $1;
BEGIN
    select count(*) as lol from ticket_flights where x > 20000;
    RETURN  lol;
END;
$$;

alter function example(real) owner to postgres;

